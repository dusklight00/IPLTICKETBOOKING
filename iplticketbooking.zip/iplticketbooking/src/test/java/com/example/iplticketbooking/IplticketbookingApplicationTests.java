package com.example.iplticketbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplticketbookingApplicationTests {

	@Test
	void contextLoads() {
	}

}

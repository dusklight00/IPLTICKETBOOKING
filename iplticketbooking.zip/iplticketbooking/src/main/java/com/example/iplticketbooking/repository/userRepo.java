package com.example.iplticketbooking.repository;
import org.springframework.data.repository.CrudRepository;

import com.example.iplticketbooking.entity.user;
public interface userRepo extends CrudRepository<user,Long> {
    public user findByUserName(String userName);
}
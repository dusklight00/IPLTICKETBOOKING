package com.example.iplticketbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IplticketbookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(IplticketbookingApplication.class, args);
	}

}
